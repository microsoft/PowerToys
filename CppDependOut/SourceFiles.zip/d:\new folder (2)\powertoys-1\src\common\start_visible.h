#pragma once

bool is_start_visible();
