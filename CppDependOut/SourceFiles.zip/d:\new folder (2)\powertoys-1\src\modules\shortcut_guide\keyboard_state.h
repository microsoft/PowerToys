#pragma once
bool winkey_held();
bool only_winkey_key_held();
