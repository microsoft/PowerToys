#pragma once
#include <interface/lowlevel_keyboard_event_data.h>

void start_lowlevel_keyboard_hook();
void stop_lowlevel_keyboard_hook();
