#pragma once

#include <interface/win_hook_event_data.h>

void start_win_hook_event();
void stop_win_hook_event();
