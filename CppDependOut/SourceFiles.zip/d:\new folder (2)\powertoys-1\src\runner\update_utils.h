#pragma once

bool start_msi_uninstallation_sequence();
void github_update_worker();
bool launch_pending_update();