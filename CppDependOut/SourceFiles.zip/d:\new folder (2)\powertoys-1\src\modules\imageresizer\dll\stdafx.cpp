#include "stdafx.h"
#pragma comment(lib, "windowsapp")