#pragma once

#include <string_view>

void dispatch_to_backround_handler(std::wstring_view argument);
