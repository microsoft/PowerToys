class CImageResizerExtModule : public ATL::CAtlDllModuleT<CImageResizerExtModule>
{
public:
    DECLARE_LIBID(LIBID_ImageResizerExtLib)
    DECLARE_REGISTRY_APPID_RESOURCEID(IDR_IMAGERESIZEREXT, "{0C866E7B-65CB-4E7D-B1DD-D014F000E8D8}")
};

extern class CImageResizerExtModule _AtlModule;
