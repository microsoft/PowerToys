#pragma once
#define WIN32_LEAN_AND_MEAN
#include <windows.h>
#include <common/common.h>
#include <ProjectTelemetry.h>